<style>
    img {
        height: 50px;
    }
</style>
<?php

include "../Database/categorydatabase.php";





            
if(isset($_POST['productBtn'])){

        $productName =  $_POST['Pro_Name'];
        $productQunatity =  $_POST['Pro_Qty'];
        $productPrice =  $_POST['Pro_Price'];
        $productImage =  $_FILES['Pro_Image'];
        $productDescription =  $_POST['Pro_Det'];
        $productCategory =  $_POST['catId'];
     
        $fileExten = pathinfo($productImage['name'] , PATHINFO_EXTENSION);
        $fileName  =  bin2hex(random_bytes(8));
        $productImageName  = $fileName . ".".$fileExten;

        move_uploaded_file($productImage['tmp_name'], "../Images/Freshmart_Products_Images/".$productImageName);

        $qurey = "call add_products('$productName','$productQunatity', '$productPrice','$productImageName','$productDescription','$productCategory')";
        $res  = mysqli_query($conn  , $qurey);
        
      
    if ($res) {
        echo "<script> location.assign('showPro.php')   </script>";
    } else {
        echo ("Try again");
    }

    

}




?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DarkPan - Bootstrap 5 Admin Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php include "./include/sidebar.php" ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <?php include "./include/navbar.php" ?>
            <!-- Navbar End -->

            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-md-12 text-center ">
                        <h4>Add New Product </h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="bg-secondary rounded h-100 p-2">
                            <form method="post" enctype="multipart/form-data">
                              

                                <div class="mb-5 mt-5">
                                    <h6 class="mb-4">Add new Product</h6>
                                </div>

                                <div class="mb-3">
                                    <label>Product Name</label>
                                    <input class="form-control bg-dark" name="Pro_Name" type="text">

                                </div>

                                <div class="mb-3">
                                    <label>Product Qunatiy</label>
                                    <input class="form-control bg-dark" min="1" name="Pro_Qty" type="number">

                                </div>
                                <div class="mb-3">
                                    <label>Product Price</label>
                                    <input class="form-control bg-dark" name="Pro_Price" type="text">

                                </div>
                               
                                <div class="mb-3">
                                    <label>Product Image</label>
                                    <input class="form-control bg-dark" name="Pro_Image" type="file">

                                </div>
                               
                                <div class="mb-3">
                                    <label>Product Details</label>
                                    <input class="form-control bg-dark" name="Pro_Det" type="text">

                                </div>
                                <div class="mb-3">
                                    <label>Select Category</label>
                                   <select name="catId" id="" class="form-control">
                                    <option >Select Category</option>
                                   
                                    <?php    

                                            $_qurey = "call select_Category";
                                            $res = mysqli_query($conn , $_qurey );

                                            while($row = mysqli_fetch_array($res))
                                            {?>
                                                     <option value="<?php echo$row[1]; ?>"><?php echo$row[1];?></option>
                                            <?php }
                                            
   

                                    
                                    ?>
                                   </select>
                                </div>
                           
                                <div class="mb-3">
                                    <button class="btn btn-primary " name="productBtn" type="submit">Add Product</button>
                                </div>
                            
                            
                               
                             
                            </form>

                        </div>
                    </div>
      
                </div>
            </div>

            <!-- Content End -->



            <!-- Back to Top -->
            <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
        </div>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="lib/chart/chart.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/tempusdominus/js/moment.min.js"></script>
        <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
        <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
</body>

</html>
