<?php 

$serverName  = "localhost";
$userName  = "root";
$serverPassword  = "";
$db_Server  = "freshmart-organic-food-sir-amjad";

$conn = "";


$conn = mysqli_connect($serverName,$userName,$serverPassword,$db_Server);

if($conn->connect_error){
    die("Connection Failed : ".$conn->connect_error );
}else{
//echo"Connected Sucksaj";
}
?>