<style>
    img {
        height: 50px;
    }
</style>
<?php

include "../Database/categorydatabase.php";


if (isset($_POST['btnSave'])) {

    $category_Name = $_POST['catName'];
    $category_Slug = $_POST['catSlug'];
    $category_Description = $_POST['catDes'];
    $category_Image = $_FILES['catImage'];
    $category_Image_Name = $category_Image['name'];

    $date  = date("d");
    $mill_second  = date("ms");


    $category_Final_Image_Name  = $category_Name .  "-" . $date  . "-" . $mill_second  . "-" . $category_Image_Name;

    move_uploaded_file($category_Image['tmp_name'], "../Images/Freshmart_Category_Images/" . $category_Final_Image_Name);

    // $query = "INSERT INTO `freshmart_category`( `catName`, `catImage`) VALUES ('$category_Name','$category_Final_Image_Name')";
    $query = "INSERT INTO `freshmart_category`( `catName`, `catSlug`, `catDes`, `catImage`) VALUES ('$category_Name','$category_Slug','$category_Description','$category_Final_Image_Name')";

    $res   =  mysqli_query($conn, $query);
    print_r($res);

    if ($res) {
        echo "<script> location.assign('addCat.php')   </script>";
    } else {
        echo ("Try again");
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DarkPan - Bootstrap 5 Admin Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php include "./include/sidebar.php" ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <?php include "./include/navbar.php" ?>
            <!-- Navbar End -->
         
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-md-12 text-center ">
                        <h4>Product categories</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="bg-secondary rounded h-100 p-4">
                            <form method="post" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <p>Product categories for your store can be managed here. To change the order of categories on the front-end you can drag and drop to sort them. To see more categories listed click the "screen options" link at the top-right of this page.</p>
                                </div>

                                <div class="mb-5 mt-5">
                                    <h6 class="mb-4">Add new category</h6>
                                </div>

                                <div class="mb-3">
                                    <label>Name</label>
                                    <input class="form-control bg-dark" name="catName" type="text">
                                    <p>The name is how it appears on your site.</p>
                                </div>
                                <div class="mb-5 mt-5">
                                    <label>Slug</label>
                                    <input class="form-control bg-dark" name="catSlug" type="text">
                                    <p>The “slug” is the URL-friendly version of the name. It is usually all lowercase and contains only letters, numbers, and hyphens.</p>
                                </div>
                                <!-- <div class="mb-3">
                                    <label>Parent Category</label>
                                    <div class="dropdown">
                                        <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Parent Category
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="#">Action</a></li>
                                            <li><a class="dropdown-item" href="#">Another action</a></li>
                                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                                        </ul>
                                    </div>
                                    <p>Assign a parent term to create a hierarchy. The term Jazz, for example, would be the parent of Bebop and Big Band.</p>
                                </div> -->
                                <div class="mb-5 mt-5">
                                    <label>Description</label><br>
                                    <textarea name="catDes" rows="4" cols="50"></textarea>
                                    <p>The description is not prominent by default; however, some themes may show it.</p>

                                </div>
                                <div class="mb-3">
                                    <label>Category Image</label>
                                    <input class="form-control bg-dark" name="catImage" type="file">
                                </div>
                                <div class="mb-3">
                                    <button class="btn btn-primary " name="btnSave" type="submit">Upload Category</button>
                                </div>
                            </form>

                        </div>
                    </div>
                    <div class="col-md-8     col-lg-8   ">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4 text-center">Show Category</h6>

                            <!-- Table Start -->
                            <div class="container-fluid ">
                                <div class="row g-4">

                                    <div class="col-sm-col-12 col-xl-12">
                                        <div class="bg-secondary rounded h-100 p-4">

                                            <table class="table table-bordered">
                                                <thead>

                                                    <tr>
                                                        <th scope="col">Category Id</th>
                                                        <th scope="col">Category Name</th>
                                                        <th scope="col">Category Slug</th>
                                                        <th scope="col">Category Description</th>
                                                        <th scope="col">Category Image</th>
                                                        <th scope="col">Edit Category</th>
                                                        <th scope="col">Delete Category</th>
                                                        <th scope="col">View Category</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                             
                                                    $qurey = "SELECT * FROM `freshmart_category`";
                                                    $res = mysqli_query($conn,    $qurey);
                                                  
                                                    
                                                  
                                                    while (  $row  = mysqli_fetch_array($res)) { ?>
                                                        <tr>

                                                            <td style="vertical-align: middle;"> <?php echo $row[0] ?></td>
                                                            <td style="vertical-align: middle;"> <?php echo $row[1] ?></td>
                                                            <td style="vertical-align: middle;"><?php echo $row[2]?></td>
                                                            <td style="vertical-align: middle;"><?php    echo $row[3];  ?></td>
                                                            <td style="vertical-align: middle;"><img src="../Images/Freshmart_Category_Images/<?php echo $row[4] ?>"></td>
                                                            <td style="vertical-align: middle;"><a href="editCat.php?id=<?php echo $row[0] ?> " class="btn btn-sm bg-danger text-white">Edit</a></td>
                                                            <td style="vertical-align: middle;"> <a href="deleteCat.php?id=<?php echo $row[0] ?> " class="btn btn-sm bg-warning text-white">Delete</a></td>
                                                            <td style="vertical-align: middle;"> <a href="view.php " class="btn btn-md bg-warning btn-sm text-white">View All</a></td>

                                                        </tr>
                                                    <?php }


                                                    ?>

                                                </tbody>
                                            </table>

                                        </div>
                                    </div>




                                </div>
                            </div>
                            <!-- Table End -->



                        </div>
                    </div>
                </div>
            </div>

            <!-- Content End -->



            <!-- Back to Top -->
            <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
        </div>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="lib/chart/chart.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/tempusdominus/js/moment.min.js"></script>
        <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
        <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
</body>

</html>