<?php

include "../Database/categorydatabase.php";

$get_id = $_GET['id'];

$query = "SELECT * FROM `freshmart_category` WHERE `catId`='$get_id'";

$res = mysqli_query($conn, $query);


if ($res && mysqli_fetch_array($res) > 0) {

    $row = mysqli_fetch_array($res);

    $folder_path = "../Images/Freshmart_Category_Images/" . $row['4']; 
    if (file_exists($folder_path)) {
        $query1 = "DELETE FROM `freshmart_category` WHERE `catId`='$get_id'";
        $res1 = mysqli_query($conn, $query1);
        
        if ($res1) {
            unlink($folder_path);
            echo "<script>alert('Data & Image Deleted.')</script>";
            echo "<script>location.assign('addCat.php')</script>";
        } else {
            echo "<script>alert('Error deleting data: " . mysqli_error($conn) . "')</script>";
        }
        
    } else {
        echo "<script>alert('Image not found. Try Again.')</script>";
    }
} else {
    echo "<script>alert('No category found with the given ID.')</script>";
}


// $get_id = $_GET['id'];


// $query = "SELECT * FROM `freshmart_category` WHERE `catId`='$get_id' ";

// $res = mysqli_query($conn, $query);

// $row  = mysqli_fetch_array($res);

// $folder_path = ".../Images/Freshmart_Category_Images/" . $row['4'];


// if (file_exists($folder_path)) {


//     $qurey1 = "DELETE FROM `freshmart_category` WHERE `catId`='$get_id'";
//     $res1 = mysqli_query($conn, $qurey1);
//     unlink($folder_path);
//     echo "<script>alert('Data & Image  Delete....')</script>";
//     echo "<script>location.assign('addCat.php')</script>";

// } else {
//     echo "<script>alert('Try Again')</script>";
// }
?>
