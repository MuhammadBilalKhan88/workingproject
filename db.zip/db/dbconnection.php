<?php 
$host = "localhost";
$username = "root";
$password = "";
$dbname = "ecom";
$dbcon = mysqli_connect($host,$username,$password,$dbname);

if(!$dbcon){
    die("Connection Failed");
}

?>