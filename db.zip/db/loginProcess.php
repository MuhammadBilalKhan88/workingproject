<?php 
require_once('dbconnection.php');

/* echo "<pre>";
print_r($_POST); */

$user_email = $_POST['user_email'];
$user_password = $_POST['user_password'];


$query ="SELECT * FROM `users` WHERE user_email='".$user_email."' AND user_password='".$user_password."'";


$result = mysqli_query($dbcon,$query);

if($result->num_rows>0){
    $userData = mysqli_fetch_assoc($result);
   session_start();
   $_SESSION['userData']=$userData;
   header("location:welcome.php");
}else{
    $msg = base64_encode("Invalid Email or Password");
    header("location:index.php?msg=".$msg);
}


?>